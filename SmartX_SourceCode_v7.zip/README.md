# Smart-X Gateway - Part 1: Sensor Data Ingestion & Telemetry

A .NET 8 solution made up of two projects:

| Project | What it is |
|---|---|
| `SmartX.Api` | ASP.NET Core Minimal API - the ingestion / registration backend |
| `SmartX.Client` | ASP.NET Core Blazor Server dashboard - the client-facing console |

## 1. Prerequisites

- .NET 8 SDK (https://dotnet.microsoft.com/download/dotnet/8.0)
- (Optional) Docker Desktop, if you want to run everything in containers
- Visual Studio 2022 17.8+ or VS Code with the C# Dev Kit

## 2. Restore & build

From the repository root:

```bash
dotnet restore SmartX.sln
dotnet build SmartX.sln
```

If you're using Visual Studio, open `SmartX.sln`, let NuGet restore
automatically (or right-click the solution > Restore NuGet Packages), then
Build > Build Solution.

## 3. Run locally (two terminals)

**Terminal 1 - API** (listens on `http://localhost:5080`, Swagger at `/swagger`):

```bash
cd SmartX.Api
dotnet run
```

**Terminal 2 - Client dashboard** (listens on `http://localhost:5081`):

```bash
cd SmartX.Client
dotnet run
```

In Visual Studio, right-click the solution > Set Startup Projects > Multiple
startup projects > set both `SmartX.Api` and `SmartX.Client` to Start, then
run with Ctrl+F5.

Once both are running, open `http://localhost:5081` in a browser. The client
reads the API's address from `SmartX.Client/appsettings.json`
(`SmartXApi:BaseAddress`) - change this if you run the API on a different
port.

## 4. Run with Docker

```bash
docker compose up --build
```

This builds and starts both containers (`api` on 5080, `client` on 5081) and
wires the client to talk to the API over the compose network.

## 5. Using the dashboard

1. Open the client - you land on the Startup Interface, showing the three
   architectural pillars. Only Sensor Data Ingestion & Telemetry is active
   in Part 1; the other two tiles are visibly disabled.
2. Go to Sensor Ingestion, register a sensor (MAC address, deployment
   location, category).
3. A health-score card appears for the sensor - this is the dynamic
   engagement feature (see the research report). Push a few readings within
   the expected band to watch the score climb, the streak counter tick up,
   and the badge upgrade. Push an out-of-band value or hit "Simulate
   disconnect" to watch the score drop and the card pulse red.
4. Attach a config file, photo, or log file to a sensor via the file picker
   - this calls the API's multipart upload endpoint and stores the file
   under `SmartX.Api/uploads/`.
5. The live feed table at the bottom polls the API every few seconds and
   highlights anomalous readings.
6. Sections 4-6 on the same page are dedicated demo panels for the other
   required C# concepts:
   - Aggregate meter load - enter two device ids and loads (W) and click
     "Combine readings" to run `SensorReading`'s overloaded `+`, `-`, `>`,
     `<` and `==` operators.
   - Load historical batch - enter a device id and a comma-separated list
     of raw samples, click "Load batch" to push it through the jagged-array
     buffer and see it promoted into the `List<T>` archive.
   - Validate deployment tree - edit the pre-filled nested JSON (try
     changing a `"tier"` value to something wrong) and click "Validate tree"
     to see the recursive validator's pass/fail result and error messages.

## 6. Where the required C# concepts live

| Requirement | File | Where to demo it live |
|---|---|---|
| Generics (`TelemetryPacket<T>`) | `SmartX.Api/Models/TelemetryPacket.cs` | Ingestion page, section 2 (push a reading) |
| Operator overloading (`SensorReading` `+`, `-`, comparisons) | `SmartX.Api/Models/SensorModels.cs` | Ingestion page, section 4 |
| Jagged arrays -> `List<T>` archive | `SmartX.Api/Services/TelemetryStore.cs` (`IngestBatch`) | Ingestion page, section 5 |
| Recursion (nested deployment-tree validation) | `SmartX.Api/Models/DeploymentNode.cs` (`DeploymentValidator.ValidateRecursive`) | Ingestion page, section 6 |
| Dynamic engagement feature | `SmartX.Api/Services/HealthScoreService.cs` | Ingestion page, section 2 |

Each of the above is also marked in the source with a comment header
(`// ASSIGNMENT REQUIREMENT: ...`) directly above the relevant class or
method.

## 7. API surface (see Swagger for the full contract)

- `POST /api/sensors` - register a sensor
- `GET /api/sensors` - list sensors
- `POST /api/sensors/{id}/media` - multipart file upload (config/photo/log), encrypted at rest
- `GET /api/sensors/{id}/media/{fileName}/download` - decrypts and streams a stored attachment back
- `POST /api/telemetry` - push a typed reading (`ValueType`: `float` | `int` | `bool`)
- `POST /api/telemetry/{deviceId}/disconnect` - simulate a dropped sensor
- `GET  /api/telemetry/feed` - recent live readings
- `POST /api/telemetry/batch` - load a raw historical sample batch (jagged array -> archive)
- `POST /api/deployment/validate` - recursively validate a nested deployment tree

## 8. Additional quality features

- **Media encryption at rest** - every uploaded file is encrypted with
  AES-256 before it touches disk (`SmartX.Api/Services/FileEncryptionService.cs`).
  Files are stored with a `.enc` extension; the download link next to each
  attachment on the dashboard decrypts on the fly and streams the original
  file back.
- **Custom collection type** - the telemetry archive is a custom generic
  class, `TelemetryArchive<T>` (`SmartX.Api/Models/TelemetryArchive.cs`),
  not a plain `List<T>`. It tracks a per-device count alongside the
  sequential data for O(1) lookups, and evicts the oldest entry once a
  configured capacity is reached so memory stays bounded.
- **Client-side validation** - the sensor registration form validates the
  MAC address format and location length in the browser before calling the
  API, with inline error messages under each field
  (`SmartX.Client/Pages/Ingestion.razor`).
- **Responsive layout** - the dashboard collapses to a single column and
  full-width controls below 640px, and the telemetry table scrolls
  horizontally instead of breaking the page layout on narrow screens.

## 9. Troubleshooting

- **Missing Swashbuckle / AddSwaggerGen errors**: the API project references
  `Swashbuckle.AspNetCore` for its Swagger UI. If NuGet hasn't restored it,
  right-click `SmartX.Api` > Manage NuGet Packages > Installed, and confirm
  it's there; otherwise restore the solution again.
- **Blazor hosting model errors**: this client uses the classic
  `_Host.cshtml` + `MapBlazorHub()` Blazor Server model, which is fully
  supported on .NET 8. If your SDK version scaffolds a different template by
  default elsewhere, that does not affect this project - it already has its
  own `Program.cs` and hosting setup.

## 10. Video demo

[Add your video link here once recorded]

## 11. Next parts

Part 2 will light up Real-Time Command Stream & History; the final PoE will
light up Network Topology & Mesh Routing. Keep this repository as the base
for both.
